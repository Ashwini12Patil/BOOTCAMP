﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace CollectionGenerics
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList AL = new ArrayList();
            Queue Q = new Queue();
            Stack S = new Stack();

            AL.Add("Ashwini");
            AL.Add(10);

            foreach (Object o in AL)
            {
                Console.WriteLine(o);
            }

            Q.Enqueue("Ashwini");
            Q.Enqueue(20);

            foreach (Object o in Q)
            {
                Console.WriteLine(o);
            }

            S.Push("Ashwini");
            S.Push(30);

            foreach (Object o in S)
            {
                Console.WriteLine(o);
            }

            List<Int32> IG = new List<Int32>();
            IG.Add(100);
            IG.AddRange(new int[] { 20, 30, 40, 50 });

            foreach (int i in IG)
            {
                Console.WriteLine(i);
            }

        }
    }
}
