﻿using System;

namespace OOPS_BASIC
{

    class ClassObjectDemo
    {
        public int a;
    }

    struct StructRefrenceDemo
    {
        public int a;
    }

    public class Encapsulation
    {
        private int a;
        protected int b;
        public int c;
    }

    public class EncapsulationDemo : Encapsulation
    { 

        public void EnDemoFun()
        {
            b = 20;
        }
    }

    public class Poly_Func_OverLoading
    {
        public void Demo1()
        {
            Console.WriteLine("1st Function - no return type, no parameter.");
        }

        public void Demo1(int a)
        {
            Console.WriteLine("2nd Function - no return type, 1 integer parameter");
        }

        public void Demo1(int a,string b)
        {
            Console.WriteLine("3rd Function - no return type, 1 integer parameter + 1 string parameter.");
        }
    }

    abstract class ABS_Parent
    {
        public void DemoAbstract()
        {
            Console.WriteLine("Normal Method of Normal Class Named - ABS_Parent is called.");
        }
        public abstract void DemoAbstract_Fun();
    }

    abstract class ABS_Child:ABS_Parent
    {
        public abstract void DemoAbs_Fun();
        public void Normal_Fun()
        {
            Console.WriteLine("Normal Method of Class - ABS_Child is called.");
        }

        public override void DemoAbstract_Fun()
        {
            Console.WriteLine("Abstract Method of Abstract Class Named - ABS_parent is called IN ABS_Child.");
        }
    }

    class ABS_Child_Fun : ABS_Child
    {
        public override void DemoAbs_Fun()
        {
            Console.WriteLine("Abstract Method of Abstract Class Named - ABS_Child is called.");
        }

        public void DemoChildFun()
        {
            Console.WriteLine("Normal Method of Child Class Named - ABS_Child_Fun is called.");
        }
        public void DemoAbstract_Fun()
        {
            Console.WriteLine("Abstract Method of Abstract Class Named - ABS_Child is called IN ABS_Child_Fun.");
        }
    }

    interface Iparent1
    {
        void IAbsDemo1();
    }
    interface Iparent2
    {
        void IAbsDemo1();
    }

   public class IDemo1 : Iparent1, Iparent2
    {
        void Iparent1.IAbsDemo1()
        {
            Console.WriteLine("Interface IParent Method Override.");
        }
        void Iparent2.IAbsDemo1()
        {
            Console.WriteLine("Interface IParent2 Method Override.");
        }
    }

    public class IDemo2 : Iparent1, Iparent2
    {
        void Iparent1.IAbsDemo1()
        {
            Console.WriteLine("Interface IParent Method Override.");
        }
        void Iparent2.IAbsDemo1()
        {
            Console.WriteLine("Interface IParent2 Method Override.");
        }
    }

    public class IDemo3 : Iparent1, Iparent2
    {
        void Iparent1.IAbsDemo1()
        {
            Console.WriteLine("Interface IParent Method Override.");
        }
        void Iparent2.IAbsDemo1()
        {
            Console.WriteLine("Interface IParent2 Method Override.");
        }
    }

    public static class StaticClass
    {
        public static int a;
    }
    public  class StaticClass2
    {
        public  int a1;
        public static int b;
    }

    class NotSealed
    {
        public int a = 100;
    }
    sealed class SealedClass : NotSealed
    {
        public int b;
    }

    public partial class P1
    {
        public int p1;
    }
    public partial class P1
    {
        public int p2;
    }
    public class P3 : P1
    {
        public int Child;
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            ClassObjectDemo ClassDemo1 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo2 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo3 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo4 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo5 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo6 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo7 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo8 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo9 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo10 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo11 = new ClassObjectDemo();
            ClassObjectDemo ClassDemo12 = new ClassObjectDemo();

            ClassDemo1.a = 11;
            ClassDemo2.a = 12;
            ClassDemo3.a = 13;
            ClassDemo4.a = 14;
            ClassDemo5.a = 15;
            ClassDemo6.a = 16;
            ClassDemo7.a = 17;
            ClassDemo8.a = 18;
            ClassDemo9.a = 19;
            ClassDemo10.a = 20;
            ClassDemo11.a = 21;
            ClassDemo12.a = 22;

            Console.WriteLine("Class Demo ");
            Console.WriteLine(ClassDemo1.a);
            Console.WriteLine(ClassDemo2.a);
            Console.WriteLine(ClassDemo3.a);    
            Console.WriteLine(ClassDemo4.a);
            Console.WriteLine(ClassDemo5.a);
            Console.WriteLine(ClassDemo6.a);
            Console.WriteLine(ClassDemo7.a);
            Console.WriteLine(ClassDemo8.a);
            Console.WriteLine(ClassDemo9.a);
            Console.WriteLine(ClassDemo10.a);
            Console.WriteLine(ClassDemo11.a);
            Console.WriteLine(ClassDemo12.a);

            StructRefrenceDemo structRefrenceDemo1 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo2 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo3 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo4 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo5 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo6 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo7 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo8 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo9 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo10 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo11 = new StructRefrenceDemo();
            StructRefrenceDemo structRefrenceDemo12 = new StructRefrenceDemo();

            structRefrenceDemo1.a = 1;
            structRefrenceDemo11.a = 2; 
            structRefrenceDemo12.a = 3;
            structRefrenceDemo2.a = 4;
            structRefrenceDemo3.a = 5;
            structRefrenceDemo4.a = 6;
            structRefrenceDemo5.a = 7;
            structRefrenceDemo6.a = 8;
            structRefrenceDemo7.a = 9;
            structRefrenceDemo8.a = 10;
            structRefrenceDemo9.a = 11;
            structRefrenceDemo10.a = 12;

            Console.WriteLine("Structure Demo ");
            Console.WriteLine(structRefrenceDemo1.a);
            Console.WriteLine(structRefrenceDemo2.a);
            Console.WriteLine(structRefrenceDemo3.a);
            Console.WriteLine(structRefrenceDemo4.a);
            Console.WriteLine(structRefrenceDemo5.a);
            Console.WriteLine(structRefrenceDemo6.a);
            Console.WriteLine(structRefrenceDemo7.a);
            Console.WriteLine(structRefrenceDemo8.a);
            Console.WriteLine(structRefrenceDemo9.a);
            Console.WriteLine(structRefrenceDemo10.a);
            Console.WriteLine(structRefrenceDemo11.a);
            Console.WriteLine(structRefrenceDemo12.a);

            //Encapsulation Demo
            Encapsulation en=new Encapsulation();
            en.c = 100;
            Console.WriteLine("Public Variable of Encapulation Class : "+en.c);
            Poly_Func_OverLoading PFOL = new Poly_Func_OverLoading();
            PFOL.Demo1();
            PFOL.Demo1(1);
            PFOL.Demo1(1, "String");

            ABS_Child_Fun ABSDemo1 = new ABS_Child_Fun();
            ABSDemo1.Normal_Fun();
            ABSDemo1.DemoAbs_Fun();
            ABSDemo1.DemoChildFun();
            ABSDemo1.DemoAbstract();
            ABSDemo1.DemoAbstract_Fun();

            ABS_Child aBS_Child = new ABS_Child_Fun();
            aBS_Child.Normal_Fun();
            aBS_Child.DemoAbs_Fun();
            aBS_Child.DemoAbstract();
            aBS_Child.DemoAbstract_Fun();

            Iparent1 ip = new IDemo1();
            ip.IAbsDemo1();
            Iparent2 ip1 = new IDemo2();
            ip1.IAbsDemo1();
            Iparent1 ip2 = new IDemo3();
            ip2.IAbsDemo1();

            StaticClass.a = 10;
            StaticClass2 SC = new StaticClass2();
            SC.a1 = 10;
            StaticClass2.b = 20;

            P1 par= new P1();
            par.p2 = 100;
            par.p1 = 200;

            P3 par1 = new P3();
            par1.p2 = 300;
            par1.p1 = 400;
        }
    }
}
